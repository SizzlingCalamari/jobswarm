
// Saves a block of data as a GIF file on disk.

int	saveGIF(char *filename,int wid,int hit,const unsigned char *pal,const unsigned char *data);

